<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class NewsParagrafController extends Controller
{
    //
}
