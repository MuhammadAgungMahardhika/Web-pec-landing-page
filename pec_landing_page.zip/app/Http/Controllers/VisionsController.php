<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class VisionsController extends Controller
{
    //
}
