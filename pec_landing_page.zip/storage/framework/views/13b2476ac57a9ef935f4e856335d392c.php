<section id="posts" class="posts">
    <div class="container" data-aos="fade-up">
        <div class="section-title">
            <h2>Postingan</h2>
            <p>
                Magnam dolores commodi suscipit. Necessitatibus eius consequatur
                ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam
                quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea.
                Quia fugiat sit in iste officiis commodi quidem hic quas.
            </p>
        </div>

        <div class="row">
            <div class="testimonials-slider swiper" data-aos="fade-up" data-aos-delay="100">
                <div class="mt-2 text-end">
                    <a href="<?php echo e(url('posts')); ?>" class="text-success mt-4">Lihat semua postingan</a>
                </div>
                <div class="swiper-wrapper p-4">
                    <?php $no = 5; ?>
                    <?php $__currentLoopData = $postData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-12 d-flex align-items-stretch justify-content-center swiper-slide p-4">
                            <a href="<?php echo e(url('post') . '/' . $post->slug); ?>"
                                style="text-decoration: none; color: inherit;">
                                <div class="card shadow-pec-success" style="width: 23rem">
                                    <img src="<?php echo e(asset('assets/img/posts/' . $post->brosur_url)); ?>" class="card-img-top"
                                        alt="<?php echo e($post->brosur_url); ?>">
                                    <div class="card-body">
                                        <h5 class="card-title fw-medium"><?php echo e($post->title); ?></h5>
                                        <i class="fa fa-calendar"></i>
                                        <span class=" fw-lighter"><?php echo e($post->publication_date); ?></span>
                                        <p class="card-text mt-4"><?php echo e($post->summary); ?></p>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="swiper-pagination"></div>
            </div>
        </div>

    </div>
</section>
<?php /**PATH C:\Dokumen Agung\pec_landing_page\resources\views/home_section/posts.blade.php ENDPATH**/ ?>