<nav id="navbar" class="navbar">
    <ul>
        <li>
            <a class="nav-link scrollto active" href="<?php echo e(url('/#home')); ?>"><?php echo e($navbarData[0]); ?></a>
        </li>
        <li><a class="nav-link scrollto" href="<?php echo e(url('/#about')); ?> "><?php echo e($navbarData[1]); ?></a></li>
        
        <li> <a class="nav-link scrollto" href="<?php echo e(url('/#posts')); ?>"><?php echo e($navbarData[3]); ?></a></li>
        
        
        <li><a class="nav-link scrollto" href="<?php echo e(url('/#team')); ?>"><?php echo e($navbarData[6]); ?></a></li>
        <li><a class="nav-link scrollto" href="<?php echo e(url('/#contact')); ?>"><?php echo e($navbarData[7]); ?></a></li>
        <li><a class="getstarted scrollto" href="#"><?php echo e($navbarData[8]); ?></a></li>

        <li class="dropdown">
            <a href="#"><img src="<?php echo e(asset('assets/logo/' . $navbarData[9])); ?>" alt=""
                    width="30"></a>
            
        </li>
    </ul>

    <i class="bi bi-list mobile-nav-toggle"></i>

</nav>
<?php /**PATH C:\Dokumen Agung\pec_landing_page\resources\views/template/navbar.blade.php ENDPATH**/ ?>