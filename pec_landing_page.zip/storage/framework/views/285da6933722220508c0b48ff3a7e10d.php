<section id="about" class="about">
    <div class="container" data-aos="fade-up">
        <div class="section-title">
            <h2>Tentang Pec</h2>
            <img src="<?php echo e(asset('assets/logo/logo_pec.png')); ?>" alt="" width="200">
            <img src="<?php echo e(asset('assets/img/accreditation/logo-kars.webp')); ?>" alt="akreditasi paripurna"
                title="Logo KARS yang menunjukkan bahwa rumah sakit telah mencapai akreditasi paripurna, menandakan standar tinggi dalam pelayanan kesehatan">
            <p>
                <?php echo e($hospitalData->about); ?>

            </p>
        </div>

        <div class="row content">
            <div class="col-lg-6">
                <p> Visi </p>
                <ul>
                    <?php $__currentLoopData = $hospitalData->visions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <i class="ri-check-double-line"></i> <?php echo e($vision->description); ?>

                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <div class="col-lg-6 pt-4 pt-lg-0">
                <p>Misi</p>
                <ul>
                    <?php $__currentLoopData = $hospitalData->missions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <i class="ri-check-double-line"></i> <?php echo e($mission->description); ?>

                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                
            </div>
        </div>

    </div>
</section>
<?php /**PATH C:\Dokumen Agung\pec_landing_page\resources\views/home_section/about.blade.php ENDPATH**/ ?>