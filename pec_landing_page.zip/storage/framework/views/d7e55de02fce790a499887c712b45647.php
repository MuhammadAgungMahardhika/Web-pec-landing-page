
<?php $__env->startSection('container'); ?>
    <section id="home" class="d-flex align-items-center">
        <div class="container position-relative" data-aos="fade-up" data-aos-delay="100">
            <div id="leaves" class="text-end" style="margin-top: -300px; position:fixed;">
                <i></i>
                <i></i>
                <i></i>
                <i></i>
                <i></i>
                <i></i>
                <i></i>
                <i></i>
                <i></i>
                <i></i>
                <i></i>
                <i></i>
                <i></i>
                <i></i>
                <i></i>
            </div>
            <div class="row justify-content-center">
                <div class="col-xl-7 col-lg-9 text-center">
                    <h1 class="text-success"><?php echo e($hospitalData->name); ?></h1>
                    <h2 class="text-pec-primary"><?php echo e($hospitalData->moto); ?></h2>
                </div>
            </div>
            <div class="text-center">
                <a href="https://antrian.padangeyecenter.com/booking" class="btn-get-started scrollto bg-success">Booking
                    now</a>
            </div>

            <div class="row icon-boxes p-4">
                <?php
                    $delay = 200;
                ?>
                <?php $__currentLoopData = $landingPageMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0" data-aos="zoom-in"
                        data-aos-delay="<?php echo e($delay); ?>">
                        <div class="icon-box ">
                            <div class="icon"><i class="<?php echo e($menu['icon']); ?>"></i></div>
                            <h4 class="title"><a href="<?php echo e($menu['link']); ?>"><?php echo e($menu['title']); ?></a></h4>
                            <p class="description">
                                <?php echo e($menu['description']); ?>

                            </p>
                        </div>
                    </div>
                    <?php
                        $delay += 150;
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </section>


    <main id="main">
        <?php echo $__env->make('home_section.about', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('home_section.about_count', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('home_section.about_video', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        
        <?php echo $__env->make('home_section.posts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        
        
        <?php echo $__env->make('home_section.team', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        
        <?php echo $__env->make('home_section.contact', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Dokumen Agung\pec_landing_page\resources\views/pages/home.blade.php ENDPATH**/ ?>