<section id="team" class="team section-bg">
    <div class="container" data-aos="fade-up">
        <div class="section-title">
            <h2><?php echo e($teamSection['title']); ?></h2>
            <p>
                <?php echo e($teamSection['description']); ?>

            </p>
        </div>
        <div class="row">
            <div class="testimonials-slider swiper p-4 bg-white" data-aos="fade-up" data-aos-delay="100">
                <div class="swiper-wrapper ">
                    <?php $delay = 100 ?>
                    <?php $__currentLoopData = $teamSection['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-12 d-flex align-items-stretch justify-content-center swiper-slide "
                            data-aos="fade-up" data-aos-delay="<?php echo e($delay); ?>">
                            <div class="member " style="width: 20rem">
                                <div class="member-img shadow-pec-success">
                                    <img src="<?php echo e(asset('assets/img/team/' . $member->image_url)); ?>" class="img-fluid "
                                        alt="" />
                                    <div class="social ">
                                        <a href="https://twitter.com/<?php echo e($member->twitter); ?>"><i
                                                class="bi bi-twitter"></i></a>
                                        <a href="https://www.facebook.com/<?php echo e($member->facebook); ?>"><i
                                                class="bi bi-facebook"></i></a>
                                        <a href="https://www.instagram.com/<?php echo e($member->instagram); ?>"><i
                                                class="bi bi-instagram"></i></a>
                                        <a href="https://www.linkedin.com/in/<?php echo e($member->linkedin); ?>"><i
                                                class="bi bi-linkedin"></i></a>
                                    </div>
                                </div>
                                <div class="member-info">
                                    <h4><?php echo e($member->name); ?></h4>
                                    <span><?php echo e($member->position); ?></span>
                                </div>
                            </div>
                        </div>
                        <?php $delay += 150  ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="swiper-pagination"></div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\Dokumen Agung\pec_landing_page\resources\views/home_section/team.blade.php ENDPATH**/ ?>